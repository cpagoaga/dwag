<?php

	echo '<br><br><br><br>';


	$ocdi_fields_static = array(
		'options_global_page_brand_color' => '',
		'_options_global_page_brand_color' => 'field_591ac509cfa00',
		'options_global_page_background_color' => '',
		'_options_global_page_background_color' => 'field_591ac509d1208',
		'options_global_page_background_image' => '',
		'_options_global_page_background_image' => 'field_591ac509cfdd8',
		'options_global_page_background_size' => 'cover',
		'_options_global_page_background_size' => 'field_591ac509d01a8',
		'options_global_page_background_position' => 'center',
		'_options_global_page_background_position' => 'field_591ac509d05b5',
		'options_global_page_background_repeat' => 'no_repeat',
		'_options_global_page_background_repeat' => 'field_591ac509d09b7',
		'options_global_page_background_attach' => '0',
		'_options_global_page_background_attach' => 'field_591ac509d0dce',
		'options_global_page_sidebar' => 'without',
		'_options_global_page_sidebar' => 'field_59390deaf218c',
		'options_global_page_use_boxed_wrapper' => '0',
		'_options_global_page_use_boxed_wrapper' => 'field_59381c77504b1',
		'options_global_page_is_wrapped' => '1',
		'_options_global_page_is_wrapped' => 'field_591ac509d31f3',
		'options_global_page_add_top_padding' => '1',
		'_options_global_page_add_top_padding' => 'field_591ac509d3606',
		'options_global_page_text_typo' => '',
		'_options_global_page_text_typo' => 'field_591ac509d1630',
		'options_global_page_headings_typo' => '',
		'_options_global_page_headings_typo' => 'field_591ac509d1a45',
		'options_global_page_subtitles_typo' => '',
		'_options_global_page_subtitles_typo' => 'field_591ac509d2622',
		'options_global_page_show_breadcrumbs' => '1',
		'_options_global_page_show_breadcrumbs' => 'field_591ac509d29ee',
		'options_global_breadcrumbs_separator' => '',
		'_options_global_breadcrumbs_separator' => 'field_591b10dbb4a85',
		'options_global_page_show_home_breadcrumb' => '1',
		'_options_global_page_show_home_breadcrumb' => 'field_591ac509d2e0d',
		'options_global_breadcrumbs_show_author' => '1',
		'_options_global_breadcrumbs_show_author' => 'field_591ef1473ef35',
		'options_global_breadcrumbs_show_tags' => '1',
		'_options_global_breadcrumbs_show_tags' => 'field_591ef1773ef36',
		'options_global_breadcrumbs_show_cats' => '1',
		'_options_global_breadcrumbs_show_cats' => 'field_591ef18a3ef37',
		'options_global_breadcrumbs_background_color' => '',
		'_options_global_breadcrumbs_background_color' => 'field_591ef0e8d845b',
		'options_global_breadcrumbs_font_color' => '',
		'_options_global_breadcrumbs_font_color' => 'field_591ef10cd845c',
		'options_global_page_smooth_scroll' => '0',
		'_options_global_page_smooth_scroll' => 'field_591ac509d3a3e',
		'options_global_page_preloader' => '1',
		'_options_global_page_preloader' => 'field_591ac509d3e51',
		'options_global_page_show_arrow' => '1',
		'_options_global_page_show_arrow' => 'field_591ac509d4234',
		'options_global_page_arrow_color' => '',
		'_options_global_page_arrow_color' => 'field_591ac509d465a',
		'options_global_full_width_margins_size' => '',
		'_options_global_full_width_margins_size' => 'field_591b10dbb4a85_fwgaps',
		'options_global_page_custom_css' => '',
		'_options_global_page_custom_css' => 'field_591ac509d4a44',
		'options_global_preloader_shapes_color' => '',
		'_options_global_preloader_shapes_color' => 'field_592d5938aee39',
		'options_global_preloader_background_color' => '',
		'_options_global_preloader_background_color' => 'field_592d4579aee38',
		'options_global_header_menu_style' => 'style1',
		'_options_global_header_menu_style' => 'field_59229bda317ae',
		'options_global_logo_type' => 'sitename',
		'_options_global_logo_type' => 'field_59229bda32383',
		'options_global_logo_image_light' => '',
		'_options_global_logo_image_light' => 'field_5936b2dd92771',
		'options_global_logo_image_light_retina' => '',
		'_options_global_logo_image_light_retina' => 'field_5936b357132bf',
		'options_global_logo_image_light_mobile' => '',
		'_options_global_logo_image_light_mobile' => 'field_5936b371132c0',
		'options_global_logo_image' => '',
		'_options_global_logo_image' => 'field_59229bda32f63',
		'options_global_logo_image_dark' => '',
		'_options_global_logo_image_dark' => 'field_5936af24f4b7e',
		'options_global_logo_image_dark_retina' => '',
		'_options_global_logo_image_dark_retina' => 'field_5936afd421bba',
		'options_global_logo_image_dark_mobile' => '',
		'_options_global_logo_image_dark_mobile' => 'field_5936affb21bbb',
		'options_global_logo_image_dark_variant' => '',
		'_options_global_logo_image_dark_variant' => 'field_5936add283a9a',
		'options_global_header_logo_by_default' => 'light_variant',
		'_options_global_header_logo_by_default' => 'field_5937e1905d075',
		'options_global_header_logo_when_fixed' => 'custom',
		'_options_global_header_logo_when_fixed' => 'field_5937e1905d075_fixed',
		'options_global_logo_image_fixed' => '',
		'_options_global_logo_image_fixed' => 'field_5936af24f4b7e_fix',
		'options_global_logo_image_fixed_retina' => '',
		'_options_global_logo_image_fixed_retina' => 'field_5936afd421bba_fix',
		'options_global_logo_image_fixed_mobile' => '',
		'_options_global_logo_image_fixed_mobile' => 'field_5936affb21bbb_fix',
		'options_global_logo_image_fixed_variant' => '',
		'_options_global_logo_image_fixed_variant' => 'field_5936add283a9a_fix',
		'options_global_menu_type' => 'full',
		'_options_global_menu_type' => 'field_59229bda3374d',
		'options_global_menu_hamburger_align' => 'right',
		'_options_global_menu_hamburger_align' => 'field_59229bda3374dmod2',
		'options_global_fullscreen_menu_style' => 'simple',
		'_options_global_fullscreen_menu_style' => 'field_59229bda317ae_modd',
		'options_global_fullscreen_menu_background_color' => '',
		'_options_global_fullscreen_menu_background_color' => 'field_59229bda33b33dandmod',
		'options_global_fullscreen_menu_text_typo' => 'size"":""12px""}',
		'_options_global_fullscreen_menu_text_typo' => 'field_59229bda33f44867i7a6',
		'options_global_header_onepage_mode' => '0',
		'_options_global_header_onepage_mode' => 'field_59229bda3432amods',
		'options_global_header_menu_fixed' => '1',
		'_options_global_header_menu_fixed' => 'field_59229bda3432a',
		'options_global_header_menu_use_wrapper' => '1',
		'_options_global_header_menu_use_wrapper' => 'field_59229bda31bb0',
		'options_global_header_menu_add_cap' => 'no',
		'_options_global_header_menu_add_cap' => 'field_59229bda31f95',
		'options_global_header_menu_background_color' => '',
		'_options_global_header_menu_background_color' => 'field_59229bda33b3d',
		'options_global_header_menu_text_typo' => '',
		'_options_global_header_menu_text_typo' => 'field_59229bda33f44',
		'options_global_header_menu_hide_border' => '1',
		'_options_global_header_menu_hide_border' => 'field_59229bda34745',
		'options_global_header_menu_border_type' => 'dotted',
		'_options_global_header_menu_border_type' => 'field_59229bda34f19',
		'options_global_header_menu_border_color' => '',
		'_options_global_header_menu_border_color' => 'field_59229bda34b30',
		'options_global_header_menu_height' => '',
		'_options_global_header_menu_height' => 'field_592d3cfcc0e1c',
		'options_global_header_menu_social_links' => '3',
		'_options_global_header_menu_social_links' => 'field_59229bda366f4mod',
		'options_global_header_hide_search' => '0',
		'_options_global_header_hide_search' => 'field_592d43df9e26c',
		'options_global_header_menu_hide_contacts_bar' => '1',
		'_options_global_header_menu_hide_contacts_bar' => 'field_59229bda35701',
		'options_global_subheader_height' => '',
		'_options_global_subheader_height' => 'field_592d3dfbff372',
		'options_global_header_menu_contacts_bar_background' => '',
		'_options_global_header_menu_contacts_bar_background' => 'field_59229bda36adb',
		'options_global_header_menu_contacts_bar_text_typo' => '',
		'_options_global_header_menu_contacts_bar_text_typo' => 'field_59229bda36ed1',
		'options_global_header_menu_subheader_items_left' => '',
		'_options_global_header_menu_subheader_items_left' => 'field_59229bda366f4',
		'options_global_header_menu_subheader_items_right' => '',
		'_options_global_header_menu_subheader_items_right' => 'field_59229bda366f5',
		'options_global_header_title_background_type' => 'color',
		'_options_global_header_title_background_type' => 'field_5922a0ea1eaeb',
		'options_global_header_background_color' => '',
		'_options_global_header_background_color' => 'field_59229bda37ea5',
		'options_global_header_title_background_image' => '',
		'_options_global_header_title_background_image' => 'field_5922a2fd080e8',
		'options_global_header_title_background_size' => 'auto',
		'_options_global_header_title_background_size' => 'field_5922a6390c4a9',
		'options_global_header_title_background_position' => 'center',
		'_options_global_header_title_background_position' => 'field_5922a7500579b',
		'options_global_header_title_background_repeat' => 'repeat',
		'_options_global_header_title_background_repeat' => 'field_5922ab31f19b0',
		'options_global_header_use_overlay' => '1',
		'_options_global_header_use_overlay' => 'field_59229bda376e8',
		'options_global_header_overlay_color' => '',
		'_options_global_header_overlay_color' => 'field_59229bda37acf',
		'options_global_header_tilte_typo' => '',
		'_options_global_header_tilte_typo' => 'field_59229bda3827b',
		'options_global_header_subtilte_typo' => '',
		'_options_global_header_subtilte_typo' => 'field_59229d1dd0a61',
		'options_global_header_title_align' => 'center',
		'_options_global_header_title_align' => 'field_59229e431eaea',
		'options_global_header_height_fullscreen' => '0',
		'_options_global_header_height_fullscreen' => 'field_59229bda3868f',
		'options_global_header_height' => '',
		'_options_global_header_height' => 'field_59229bda38a78',
		'options_global_header_use_hero' => '0',
		'_options_global_header_use_hero' => 'field_59229bda38e8d',
		'options_global_header_menu_logo_typo' => '',
		'_options_global_header_menu_logo_typo' => 'field_59256ac3f42ec',
		'options_global_header_menu_social_links_0_social_network' => 'facebook',
		'_options_global_header_menu_social_links_0_social_network' => 'field_59229bda7b686moddd',
		'options_global_header_menu_social_links_0_url' => '',
		'_options_global_header_menu_social_links_0_url' => 'field_59229bda7ba5ajhghjhg',
		'options_global_header_menu_social_links_1_social_network' => 'github',
		'_options_global_header_menu_social_links_1_social_network' => 'field_59229bda7b686moddd',
		'options_global_header_menu_social_links_1_url' => '',
		'_options_global_header_menu_social_links_1_url' => 'field_59229bda7ba5ajhghjhg',
		'options_global_header_menu_social_links_2_social_network' => 'linkedin',
		'_options_global_header_menu_social_links_2_social_network' => 'field_59229bda7b686moddd',
		'options_global_header_menu_social_links_2_url' => '',
		'_options_global_header_menu_social_links_2_url' => 'field_59229bda7ba5ajhghjhg',
		'options_global_side_panel_position' => 'left',
		'_options_global_side_panel_position' => 'field_591ac509d09bmmod',
		'options_global_side_panel_add_padding' => '1',
		'_options_global_side_panel_add_padding' => 'field_591ac509d0dcemod7',
		'options_global_side_panel_background' => '',
		'_options_global_side_panel_background' => 'field_591ac50989679545cmmod',
		'options_global_side_panel_color' => '',
		'_options_global_side_panel_color' => 'field_591ac509cmmod',
		'options_global_side_panel_typo' => '',
		'_options_global_side_panel_typo' => 'field_591ac509d163089mod',
		'options_global_side_panel_separator' => '',
		'_options_global_side_panel_separator' => 'field_591ac50989679545e3mod',
		'options_global_side_panel_text' => '&copy; 2017, Norebro theme by <a href=""#"" target=""_blank"">Colabr.io Team</a>, All right reserved.',
		'_options_global_side_panel_text' => 'field_592fd8901f24b07333',
		'options_global_side_panel_social' => 'a:4:{i:0;s:8:""facebook"";i:1;s:7:""twitter"";i:2;s:10:""googleplus"";i:3;s:8:""linkedin"";}',
		'_options_global_side_panel_social' => 'field_592fd666235d9mod2',
		'options_global_blog_page_layout' => 'masonry',
		'_options_global_blog_page_layout' => 'field_592d60af8a7ff',
		'options_global_blog_page_animation_type' => 'default',
		'_options_global_blog_page_animation_type' => 'field_592d60af8a7ffmods',
		'options_global_blog_columns_in_row' => '1col',
		'_options_global_blog_columns_in_row' => 'field_592d60af8ac17',
		'options_global_blog_posts_per_page' => '16',
		'_options_global_blog_posts_per_page' => 'field_592d60af8b000',
		'options_global_blog_item_layout_type' => 'classic',
		'_options_global_blog_item_layout_type' => 'field_592d60af8b3f8',
		'options_global_blog_items_without_padding' => '0',
		'_options_global_blog_items_without_padding' => 'field_592d60af8bc07',
		'options_global_blog_sidebar' => 'right',
		'_options_global_blog_sidebar' => 'field_592d60af8bfef',
		'options_global_post_title_background_type' => 'inherit',
		'_options_global_post_title_background_type' => 'field_592d626d879de',
		'options_global_post_header_title_align' => 'inherit',
		'_options_global_post_header_title_align' => 'field_592d7197eeb16',
		'options_global_post_typography_settings' => 'inherit',
		'_options_global_post_typography_settings' => 'field_592d71e9e9b9c',
		'options_global_post_title_height_fullscreen' => 'inherit',
		'_options_global_post_title_height_fullscreen' => 'field_592d8434bfbfa',
		'options_global_post_header_height' => '',
		'_options_global_post_header_height' => 'field_592d845bbfbfb',
		'options_global_post_hide_subtitle' => 'generated',
		'_options_global_post_hide_subtitle' => 'field_592d72f6d085b',
		'options_global_post_hide_header_title' => 'inherit',
		'_options_global_post_hide_header_title' => 'field_592d6d3b368b2',
		'options_global_blog_page_show_breadcrumbs' => 'inherit',
		'_options_global_blog_page_show_breadcrumbs' => 'field_593dc7d2bfa16',
		'options_global_post_single_sidebar' => 'right',
		'_options_global_post_single_sidebar' => 'field_5937dfab71d1b',
		'options_global_post_hide_previous_n_next' => '0',
		'_options_global_post_hide_previous_n_next' => 'field_592d714deeb14',
		'options_global_post_hide_related_posts' => '0',
		'_options_global_post_hide_related_posts' => 'field_592d716deeb15',
		'options_global_post_use_boxed_wrapper' => 'inherit',
		'_options_global_post_use_boxed_wrapper' => 'field_593908a3311be',
		'options_global_post_page_add_wrapper' => 'inherit',
		'_options_global_post_page_add_wrapper' => 'field_592d7105a8cdb',
		'options_global_author_social_links' => '',
		'_options_global_author_social_links' => 'field_5937e0a52b873',
		'options_global_project_layout_type' => 'type_1',
		'_options_global_project_layout_type' => 'field_592fd6662265c',
		'options_global_project_show_navigation' => 'none',
		'_options_global_project_show_navigation' => 'field_592fd66622a31',
		'options_global_project_hide_breadcrumbs' => 'inherit',
		'_options_global_project_hide_breadcrumbs' => 'field_592fd66622e2c',
		'options_global_project_hide_sharing_buttons' => '0',
		'_options_global_project_hide_sharing_buttons' => 'field_592fd666231f2',
		'options_global_project_social_sharing_buttons' => 'a:5:{i:0;s:8:""facebook"";i:1;s:7:""twitter"";i:2;s:10:""googleplus"";i:3;s:9:""pinterest"";i:4;s:8:""linkedin"";}',
		'_options_global_project_social_sharing_buttons' => 'field_592fd666235d9',
		'options_global_portfolio_gallery_light' => 'dark',
		'_options_global_portfolio_gallery_light' => 'field_592fd66623dd8',
		'options_global_portfolio_page' => '',
		'_options_global_portfolio_page' => 'field_592fd666241be',
		'options_global_project_header_use_hero' => 'inherit',
		'_options_global_project_header_use_hero' => 'field_5931067c175b5',
		'options_global_portfolio_header_title_type' => 'inherit',
		'_options_global_portfolio_header_title_type' => 'field_592fe6df9bea5',
		'options_global_portfolio_use_title_overlay' => 'inherit',
		'_options_global_portfolio_use_title_overlay' => 'field_593029f1e5302',
		'options_global_portfolio_title_background_overlay_color' => '',
		'_options_global_portfolio_title_background_overlay_color' => 'field_59302aa9e5304',
		'options_global_portfolio_header_title_align' => 'inherit',
		'_options_global_portfolio_header_title_align' => 'field_593102f7b99f7',
		'options_global_portfolio_typography_settings' => 'inherit',
		'_options_global_portfolio_typography_settings' => 'field_5931041de1845',
		'options_global_woocommerce_product_description_layout' => 'default',
		'_options_global_woocommerce_product_description_layout' => 'field_593be7a6cb2ee',
		'options_global_woocommerce_shop_layout' => 'default',
		'_options_global_woocommerce_shop_layout' => 'field_58383c7ed01ae_laytype',
		'options_global_woocommerce_products_on_page' => '',
		'_options_global_woocommerce_products_on_page' => 'field_58383c7ed01ae_shop_count',
		'options_global_woocommerce_header_menu_style' => 'inherit',
		'_options_global_woocommerce_header_menu_style' => 'field_593be7a6cbac1',
		'options_global_woocommerce_header_logo_style' => 'inherit',
		'_options_global_woocommerce_header_logo_style' => 'field_59412a19f4b88',
		'options_global_woocommerce_menu_type' => 'inherit',
		'_options_global_woocommerce_menu_type' => 'field_593be7a6cc66e',
		'options_global_woocommerce_header_menu_fixed' => 'inherit',
		'_options_global_woocommerce_header_menu_fixed' => 'field_593be7a6ced67',
		'options_global_woocommerce_header_menu_use_wrapper' => 'inherit',
		'_options_global_woocommerce_header_menu_use_wrapper' => 'field_593be7a6cbea5',
		'options_global_woocommerce_header_add_cap' => 'inherit',
		'_options_global_woocommerce_header_add_cap' => 'field_59412ba9ad9b7',
		'options_global_woocommerce_header_menu_style_settings' => 'inherit',
		'_options_global_woocommerce_header_menu_style_settings' => 'field_59412c4ddd0b7',
		'options_global_woocommerce_header_menu_add_contacts_bar' => 'inherit',
		'_options_global_woocommerce_header_menu_add_contacts_bar' => 'field_593be7a6ce1ba',
		'options_global_woocommerce_header_menu_contacts_bar_style' => 'inherit',
		'_options_global_woocommerce_header_menu_contacts_bar_style' => 'field_594104c4f2c34',
		'options_global_woocommerce_header_subtitle' => '',
		'_options_global_woocommerce_header_subtitle' => 'field_593be7a6cf58a',
		'options_global_woocommerce_header_title_background_type' => 'inherit',
		'_options_global_woocommerce_header_title_background_type' => 'field_593be851ebe2f',
		'options_global_woocommerce_header_use_overlay' => 'inherit',
		'_options_global_woocommerce_header_use_overlay' => 'field_593be7a6d08c2',
		'options_global_woocommerce_header_overlay_color' => '',
		'_options_global_woocommerce_header_overlay_color' => 'field_593be7a6d0cb4',
		'options_global_woocommerce_header_title_align' => 'inherit',
		'_options_global_woocommerce_header_title_align' => 'field_593d5de953e57',
		'options_global_woocommerce_page_typography_settings' => 'inherit',
		'_options_global_woocommerce_page_typography_settings' => 'field_593be7a6d14a6',
		'options_global_woocommerce_header_height_fullscreen' => '0',
		'_options_global_woocommerce_header_height_fullscreen' => 'field_593be7a6d1893',
		'options_global_woocommerce_header_height' => '',
		'_options_global_woocommerce_header_height' => 'field_593be7a6d1c53',
		'options_global_woocommerce_header_use_hero' => 'inherit',
		'_options_global_woocommerce_header_use_hero' => 'field_593be7a6d2062',
		'options_global_woocommerce_page_background_type' => 'inherit',
		'_options_global_woocommerce_page_background_type' => 'field_593be7a6d2871',
		'options_global_woocommerce_page_background_color' => '',
		'_options_global_woocommerce_page_background_color' => 'field_593be7a6d3f97',
		'options_global_woocommerce_page_show_breadcrumbs' => 'inherit',
		'_options_global_woocommerce_page_show_breadcrumbs' => 'field_593be7a6d437b',
		'options_global_woocommerce_use_boxed_wrapper' => 'inherit',
		'_options_global_woocommerce_use_boxed_wrapper' => 'field_593edd79aa843',
		'options_global_woocommerce_page_is_wrapped' => 'inherit',
		'_options_global_woocommerce_page_is_wrapped' => 'field_593be7a6d4778',
		'options_global_woocommerce_footer_text_color' => '',
		'_options_global_woocommerce_footer_text_color' => 'field_5940ecce7fe58',
		'options_global_woocommerce_footer_background_type' => 'inherit',
		'_options_global_woocommerce_footer_background_type' => 'field_5940e1dbc5ce2',
		'options_global_woocommerce_footer_widget_logo_type' => 'inherit',
		'_options_global_woocommerce_footer_widget_logo_type' => 'field_5940e241c5ce3',
		'options_global_woocommerce_footer_is_sticky' => 'inherit',
		'_options_global_woocommerce_footer_is_sticky' => 'field_5940e516ada44',
		'options_global_woocommerce_footer_is_wrapped' => 'inherit',
		'_options_global_woocommerce_footer_is_wrapped' => 'field_593be7a6d7644',
		'options_global_woocommerce_footer_hide' => 'inherit',
		'_options_global_woocommerce_footer_hide' => 'field_593be7a6d725e',
		'options_global_woocommerce_footer_show_copyright_section' => 'inherit',
		'_options_global_woocommerce_footer_show_copyright_section' => 'field_593be7a6d7a67',
		'options_global_woocommerce_footer_copyright_section_background' => '',
		'_options_global_woocommerce_footer_copyright_section_background' => 'field_593be7a6d7e8e',
		'options_global_woocommerce_footer_copyright_section_text_color' => '',
		'_options_global_woocommerce_footer_copyright_section_text_color' => 'field_593be7a6d82b3',
		'options_global_footer_background_color' => '',
		'_options_global_footer_background_color' => 'field_592fd8901ca70',
		'options_global_footer_background_image' => '',
		'_options_global_footer_background_image' => 'field_592fd8901ce59',
		'options_global_footer_background_size' => 'cover',
		'_options_global_footer_background_size' => 'field_592fd8901d26a',
		'options_global_footer_text_color' => '',
		'_options_global_footer_text_color' => 'field_5940ebca457f2',
		'options_global_footer_is_wrapped' => '1',
		'_options_global_footer_is_wrapped' => 'field_592fd8901ea9a',
		'options_global_footer_is_sticky' => '0',
		'_options_global_footer_is_sticky' => 'field_593916111579e',
		'options_global_footer_hide' => '0',
		'_options_global_footer_hide' => 'field_592fd8901e284',
		'options_global_footer_copyright_left' => '&copy; 2017, norebro theme by <a href=""#"" target=""_blank"">Colabr.io Team</a>.',
		'_options_global_footer_copyright_left' => 'field_592fd8901f24baes',
		'options_global_footer_copyright_right' => 'All rights reserved.',
		'_options_global_footer_copyright_right' => 'field_592fd8901f24bfee',
		'options_global_footer_copyright_text_color' => '',
		'_options_global_footer_copyright_text_color' => 'field_592fd8901fa31',
		'options_global_footer_copyright_background_color' => '',
		'_options_global_footer_copyright_background_color' => 'field_592fd8901f63a',
		'options_global_footer_hide_copyright' => '0',
		'_options_global_footer_hide_copyright' => 'field_592fd8901ee80',
		'options_global_footer_logo_type' => 'light_variant',
		'_options_global_footer_logo_type' => 'field_592fd8901ba9e',
		'options_global_google_maps_api_key' => '',
		'_options_global_google_maps_api_key' => 'field_592fe13500023',
		'options_global_wpml_show_in_header' => '1',
		'_options_global_wpml_show_in_header' => 'field_592fe13500c38'
	);

	/*
		How get:
		SQL query "SELECT option_name, option_value FROM wp_options WHERE option_name LIKE '%options_global%'"
		Export to CSV and paste here
	*/
	$ocdi_fields_to_change_string = '"options_global_side_panel_position","right"
"_options_global_side_panel_position","field_591ac509d09bmmod"
"options_global_side_panel_text","&copy; 2017, Norebro theme by <a href=""#"" target=""_blank"">Colabr.io</a>"
"_options_global_side_panel_text","field_592fd8901f24b07333"
"options_global_side_panel_social","a:4:{i:0;s:8:""facebook"";i:1;s:7:""twitter"";i:2;s:10:""googleplus"";i:3;s:8:""linkedin"";}"
"_options_global_side_panel_social","field_592fd666235d9mod2"
"options_global_header_menu_style","style1"
"_options_global_header_menu_style","field_59229bda317ae"
"options_global_logo_type","image"
"_options_global_logo_type","field_59229bda32383"
"options_global_logo_image_light","13"
"_options_global_logo_image_light","field_5936b2dd92771"
"options_global_logo_image_light_retina",
"_options_global_logo_image_light_retina","field_5936b357132bf"
"options_global_logo_image_light_mobile",
"_options_global_logo_image_light_mobile","field_5936b371132c0"
"options_global_logo_image",
"_options_global_logo_image","field_59229bda32f63"
"options_global_logo_image_dark","14"
"_options_global_logo_image_dark","field_5936af24f4b7e"
"options_global_logo_image_dark_retina",
"_options_global_logo_image_dark_retina","field_5936afd421bba"
"options_global_logo_image_dark_mobile",
"_options_global_logo_image_dark_mobile","field_5936affb21bbb"
"options_global_logo_image_dark_variant",
"_options_global_logo_image_dark_variant","field_5936add283a9a"
"options_global_header_logo_by_default","light_variant"
"_options_global_header_logo_by_default","field_5937e1905d075"
"options_global_header_logo_when_fixed","dark_variant"
"_options_global_header_logo_when_fixed","field_5937e1905d075_fixed"
"options_global_menu_type","full"
"_options_global_menu_type","field_59229bda3374d"
"options_global_header_onepage_mode","0"
"_options_global_header_onepage_mode","field_59229bda3432amods"
"options_global_header_menu_fixed","0"
"_options_global_header_menu_fixed","field_59229bda3432a"
"options_global_header_menu_use_wrapper","1"
"_options_global_header_menu_use_wrapper","field_59229bda31bb0"
"options_global_header_menu_add_cap","no"
"_options_global_header_menu_add_cap","field_59229bda31f95"
"options_global_header_menu_hide_border","0"
"_options_global_header_menu_hide_border","field_59229bda34745"
"options_global_header_menu_border_type","solid"
"_options_global_header_menu_border_type","field_59229bda34f19"
"options_global_header_menu_height","60"
"_options_global_header_menu_height","field_592d3cfcc0e1c"
"options_global_header_hide_search","0"
"_options_global_header_hide_search","field_592d43df9e26c"
"options_global_header_menu_hide_contacts_bar","0"
"_options_global_header_menu_hide_contacts_bar","field_59229bda35701"
"options_global_header_menu_contacts_bar_phone_numbers",
"_options_global_header_menu_contacts_bar_phone_numbers","field_59229bda35af2"
"options_global_header_menu_contacts_bar_emails",
"_options_global_header_menu_contacts_bar_emails","field_59229bda35ef5"
"options_global_header_menu_contacts_bar_additional",
"_options_global_header_menu_contacts_bar_additional","field_59229bda3630a"
"options_global_header_menu_contacts_bar_social_links",
"_options_global_header_menu_contacts_bar_social_links","field_59229bda366f4"
"options_global_subheader_height",
"_options_global_subheader_height","field_592d3dfbff372"
"options_global_header_title_background_type","color"
"_options_global_header_title_background_type","field_5922a0ea1eaeb"
"options_global_header_title_background_image",
"_options_global_header_title_background_image","field_5922a2fd080e8"
"options_global_header_title_background_size","auto"
"_options_global_header_title_background_size","field_5922a6390c4a9"
"options_global_header_title_background_position","center"
"_options_global_header_title_background_position","field_5922a7500579b"
"options_global_header_title_background_repeat","repeat"
"_options_global_header_title_background_repeat","field_5922ab31f19b0"
"options_global_header_use_overlay","0"
"_options_global_header_use_overlay","field_59229bda376e8"
"options_global_header_title_align","left"
"_options_global_header_title_align","field_59229e431eaea"
"options_global_header_height_fullscreen","0"
"_options_global_header_height_fullscreen","field_59229bda3868f"
"options_global_header_height","360px"
"_options_global_header_height","field_59229bda38a78"
"options_global_header_use_hero","0"
"_options_global_header_use_hero","field_59229bda38e8d"
"options_global_header_menu_background_color","#333333"
"_options_global_header_menu_background_color","field_59229bda33b3d"
"options_global_header_menu_text_typo",
"_options_global_header_menu_text_typo","field_59229bda33f44"
"options_global_header_menu_border_color",
"_options_global_header_menu_border_color","field_59229bda34b30"
"options_global_header_menu_contacts_bar_background",
"_options_global_header_menu_contacts_bar_background","field_59229bda36adb"
"options_global_header_menu_contacts_bar_text_typo",
"_options_global_header_menu_contacts_bar_text_typo","field_59229bda36ed1"
"options_global_header_background_color","#ffffff"
"_options_global_header_background_color","field_59229bda37ea5"
"options_global_header_overlay_color",
"_options_global_header_overlay_color","field_59229bda37acf"
"options_global_header_tilte_typo","{""size"":""42px"",""color"":""#404044"",""weight"":""600""}"
"_options_global_header_tilte_typo","field_59229bda3827b"
"options_global_header_subtilte_typo",
"_options_global_header_subtilte_typo","field_59229d1dd0a61"
"options_global_page_brand_color",
"_options_global_page_brand_color","field_591ac509cfa00"
"options_global_page_background_color","#f8f8f8"
"_options_global_page_background_color","field_591ac509d1208"
"options_global_page_background_image",
"_options_global_page_background_image","field_591ac509cfdd8"
"options_global_page_background_size","auto"
"_options_global_page_background_size","field_591ac509d01a8"
"options_global_page_background_position","center"
"_options_global_page_background_position","field_591ac509d05b5"
"options_global_page_background_repeat","repeat"
"_options_global_page_background_repeat","field_591ac509d09b7"
"options_global_page_background_attach","0"
"_options_global_page_background_attach","field_591ac509d0dce"
"options_global_page_sidebar","without"
"_options_global_page_sidebar","field_59390deaf218c"
"options_global_page_use_boxed_wrapper","0"
"_options_global_page_use_boxed_wrapper","field_59381c77504b1"
"options_global_page_add_top_padding","1"
"_options_global_page_add_top_padding","field_591ac509d3606"
"options_global_page_text_typo",
"_options_global_page_text_typo","field_591ac509d1630"
"options_global_page_headings_typo","{""font_family"":""Poppins"",""font_variants"":[""700"",""600"",""500"",""regular"",""300""],""font_subsets"":[""latin""]}"
"_options_global_page_headings_typo","field_591ac509d1a45"
"options_global_page_subtitles_typo",
"_options_global_page_subtitles_typo","field_591ac509d2622"
"options_global_page_show_breadcrumbs","1"
"_options_global_page_show_breadcrumbs","field_591ac509d29ee"
"options_global_breadcrumbs_separator",
"_options_global_breadcrumbs_separator","field_591b10dbb4a85"
"options_global_page_show_home_breadcrumb","1"
"_options_global_page_show_home_breadcrumb","field_591ac509d2e0d"
"options_global_breadcrumbs_show_author","1"
"_options_global_breadcrumbs_show_author","field_591ef1473ef35"
"options_global_breadcrumbs_show_tags","1"
"_options_global_breadcrumbs_show_tags","field_591ef1773ef36"
"options_global_breadcrumbs_show_cats","1"
"_options_global_breadcrumbs_show_cats","field_591ef18a3ef37"
"options_global_breadcrumbs_background_color",
"_options_global_breadcrumbs_background_color","field_591ef0e8d845b"
"options_global_breadcrumbs_font_color",
"_options_global_breadcrumbs_font_color","field_591ef10cd845c"
"options_global_page_smooth_scroll","1"
"_options_global_page_smooth_scroll","field_591ac509d3a3e"
"options_global_page_preloader","1"
"_options_global_page_preloader","field_591ac509d3e51"
"options_global_preloader_shapes_color",
"_options_global_preloader_shapes_color","field_592d5938aee39"
"options_global_preloader_background_color",
"_options_global_preloader_background_color","field_592d4579aee38"
"options_global_page_show_arrow","1"
"_options_global_page_show_arrow","field_591ac509d4234"
"options_global_page_arrow_color",
"_options_global_page_arrow_color","field_591ac509d465a"
"options_global_full_width_margins_size",
"_options_global_full_width_margins_size","field_591b10dbb4a85_fwgaps"
"options_global_page_custom_css",
"_options_global_page_custom_css","field_591ac509d4a44"
"options_global_page_is_wrapped","1"
"_options_global_page_is_wrapped","field_591ac509d31f3"
"options_global_footer_background_color",
"_options_global_footer_background_color","field_592fd8901ca70"
"options_global_footer_background_image",
"_options_global_footer_background_image","field_592fd8901ce59"
"options_global_footer_background_size","cover"
"_options_global_footer_background_size","field_592fd8901d26a"
"options_global_footer_text_color",
"_options_global_footer_text_color","field_5940ebca457f2"
"options_global_footer_is_wrapped","1"
"_options_global_footer_is_wrapped","field_592fd8901ea9a"
"options_global_footer_is_sticky","0"
"_options_global_footer_is_sticky","field_593916111579e"
"options_global_footer_hide","0"
"_options_global_footer_hide","field_592fd8901e284"
"options_global_footer_copyright_left","&copy; 2017, Norebro Theme by <a href=""#"" target=""_blank"">Colabr.io Team</a> | <a href=""#"">Privacy Policy</a> | <a href=""#"">Sitemap</a>"
"_options_global_footer_copyright_left","field_592fd8901f24baes"
"options_global_footer_copyright_right","All Rights Reserved."
"_options_global_footer_copyright_right","field_592fd8901f24bfee"
"options_global_footer_copyright_text_color",
"_options_global_footer_copyright_text_color","field_592fd8901fa31"
"options_global_footer_copyright_background_color",
"_options_global_footer_copyright_background_color","field_592fd8901f63a"
"options_global_footer_hide_copyright","0"
"_options_global_footer_hide_copyright","field_592fd8901ee80"
"options_global_footer_logo_type","custom"
"_options_global_footer_logo_type","field_592fd8901ba9e"
"options_global_woocommerce_product_description_layout","default"
"_options_global_woocommerce_product_description_layout","field_593be7a6cb2ee"
"options_global_woocommerce_shop_layout","default"
"_options_global_woocommerce_shop_layout","field_58383c7ed01ae_laytype"
"options_global_woocommerce_products_on_page",
"_options_global_woocommerce_products_on_page","field_58383c7ed01ae_shop_count"
"options_global_woocommerce_header_menu_style","inherit"
"_options_global_woocommerce_header_menu_style","field_593be7a6cbac1"
"options_global_woocommerce_header_logo_style","inherit"
"_options_global_woocommerce_header_logo_style","field_59412a19f4b88"
"options_global_woocommerce_menu_type","inherit"
"_options_global_woocommerce_menu_type","field_593be7a6cc66e"
"options_global_woocommerce_header_menu_fixed","inherit"
"_options_global_woocommerce_header_menu_fixed","field_593be7a6ced67"
"options_global_woocommerce_header_menu_use_wrapper","inherit"
"_options_global_woocommerce_header_menu_use_wrapper","field_593be7a6cbea5"
"options_global_woocommerce_header_add_cap","inherit"
"_options_global_woocommerce_header_add_cap","field_59412ba9ad9b7"
"options_global_woocommerce_header_menu_style_settings","inherit"
"_options_global_woocommerce_header_menu_style_settings","field_59412c4ddd0b7"
"options_global_woocommerce_header_menu_add_contacts_bar","inherit"
"_options_global_woocommerce_header_menu_add_contacts_bar","field_593be7a6ce1ba"
"options_global_woocommerce_header_menu_contacts_bar_style","inherit"
"_options_global_woocommerce_header_menu_contacts_bar_style","field_594104c4f2c34"
"options_global_woocommerce_header_subtitle",
"_options_global_woocommerce_header_subtitle","field_593be7a6cf58a"
"options_global_woocommerce_header_title_background_type","inherit"
"_options_global_woocommerce_header_title_background_type","field_593be851ebe2f"
"options_global_woocommerce_header_use_overlay","inherit"
"_options_global_woocommerce_header_use_overlay","field_593be7a6d08c2"
"options_global_woocommerce_header_overlay_color",
"_options_global_woocommerce_header_overlay_color","field_593be7a6d0cb4"
"options_global_woocommerce_header_title_align","inherit"
"_options_global_woocommerce_header_title_align","field_593d5de953e57"
"options_global_woocommerce_page_typography_settings","inherit"
"_options_global_woocommerce_page_typography_settings","field_593be7a6d14a6"
"options_global_woocommerce_header_height_fullscreen","0"
"_options_global_woocommerce_header_height_fullscreen","field_593be7a6d1893"
"options_global_woocommerce_header_height",
"_options_global_woocommerce_header_height","field_593be7a6d1c53"
"options_global_woocommerce_header_use_hero","inherit"
"_options_global_woocommerce_header_use_hero","field_593be7a6d2062"
"options_global_woocommerce_page_background_type","inherit"
"_options_global_woocommerce_page_background_type","field_593be7a6d2871"
"options_global_woocommerce_page_background_color",
"_options_global_woocommerce_page_background_color","field_593be7a6d3f97"
"options_global_woocommerce_page_show_breadcrumbs","inherit"
"_options_global_woocommerce_page_show_breadcrumbs","field_593be7a6d437b"
"options_global_woocommerce_use_boxed_wrapper","inherit"
"_options_global_woocommerce_use_boxed_wrapper","field_593edd79aa843"
"options_global_woocommerce_page_is_wrapped","inherit"
"_options_global_woocommerce_page_is_wrapped","field_593be7a6d4778"
"options_global_woocommerce_footer_text_color",
"_options_global_woocommerce_footer_text_color","field_5940ecce7fe58"
"options_global_woocommerce_footer_background_type","inherit"
"_options_global_woocommerce_footer_background_type","field_5940e1dbc5ce2"
"options_global_woocommerce_footer_widget_logo_type","inherit"
"_options_global_woocommerce_footer_widget_logo_type","field_5940e241c5ce3"
"options_global_woocommerce_footer_is_sticky","inherit"
"_options_global_woocommerce_footer_is_sticky","field_5940e516ada44"
"options_global_woocommerce_footer_is_wrapped","inherit"
"_options_global_woocommerce_footer_is_wrapped","field_593be7a6d7644"
"options_global_woocommerce_footer_hide","inherit"
"_options_global_woocommerce_footer_hide","field_593be7a6d725e"
"options_global_woocommerce_footer_show_copyright_section","inherit"
"_options_global_woocommerce_footer_show_copyright_section","field_593be7a6d7a67"
"options_global_woocommerce_footer_copyright_section_background",
"_options_global_woocommerce_footer_copyright_section_background","field_593be7a6d7e8e"
"options_global_woocommerce_footer_copyright_section_text_color",
"_options_global_woocommerce_footer_copyright_section_text_color","field_593be7a6d82b3"
"options_global_side_panel_add_padding","0"
"_options_global_side_panel_add_padding","field_591ac509d0dcemod7"
"options_global_side_panel_background","rgba(255,255,255,0.01)"
"_options_global_side_panel_background","field_591ac50989679545cmmod"
"options_global_side_panel_color",
"_options_global_side_panel_color","field_591ac509cmmod"
"options_global_side_panel_typo",
"_options_global_side_panel_typo","field_591ac509d163089mod"
"options_global_side_panel_separator",
"_options_global_side_panel_separator","field_591ac50989679545e3mod"
"options_global_fullscreen_menu_style","default"
"_options_global_fullscreen_menu_style","field_59229bda317ae_modd"
"options_global_footer_logo_image","14237"
"_options_global_footer_logo_image","field_592fd8901c689"
"options_global_fullscreen_menu_background_color",
"_options_global_fullscreen_menu_background_color","field_59229bda33b33dandmod"
"options_global_fullscreen_menu_text_typo",
"_options_global_fullscreen_menu_text_typo","field_59229bda33f44867i7a6"
"options_global_header_menu_social_links",
"_options_global_header_menu_social_links","field_59229bda366f4mod"
"options_global_header_menu_subheader_items_left",
"_options_global_header_menu_subheader_items_left","field_59229bda366f4"
"options_global_header_menu_subheader_items_right",
"_options_global_header_menu_subheader_items_right","field_59229bda366f5"';
	$ocdi_fields_to_change = array();

	if ( $ocdi_fields_to_change_string ) {
		$ocdi_fields_to_change = explode( "\n", $ocdi_fields_to_change_string );
		foreach ( $ocdi_fields_to_change as $key => $row ) {
			$row = trim( $row );
			$_replace_limit = 1;
			$row = str_replace( '""', '"', $row );
			if ( strrpos( $row, ',' ) == strlen( $row ) - 1 ) {
				$row .= '""';
			}
			$ocdi_fields_to_change[$key] = preg_replace( '/,/', ' => ', $row, $_replace_limit ) . ',';
			if ( substr_count( $ocdi_fields_to_change[$key], '"' ) > 4 ) {
				$_row = explode( '=>', $ocdi_fields_to_change[$key] );
				$_row[1] = trim( $_row[1] );
				$_row[1] = substr( $_row[1], 1, ( strlen( $_row[1] ) - 3 ) );
				$_row[1] = "'" . $_row[1] . "',";
				$ocdi_fields_to_change[$key] = implode( '=> ', $_row );
			}
		}
		$ocdi_fields_to_change = implode( "\n", $ocdi_fields_to_change );
		eval( '$ocdi_fields_to_change = array( ' . $ocdi_fields_to_change . ' );' );
	}

	echo '$ocdi_fields_to_change = array(<br>';
	foreach ( $ocdi_fields_to_change as $key => $value ) {
		if ( $key[0] == '_' ) {
			continue;
		}
		if ( isset( $ocdi_fields_static[$key] ) ) {
			if ( $ocdi_fields_static[$key] != $value ) {
				echo '&nbsp;&nbsp;&nbsp;&nbsp;\'' . $key . '\' => \'' . esc_html( $value ) . '\',<br>';
			}
		} else {
			echo '&nbsp;&nbsp;&nbsp;&nbsp;\'' . $key . '\' => \'' . esc_html( $value ) . '\',<br>';
			echo '&nbsp;&nbsp;&nbsp;&nbsp;\'_' . $key . '\' => \'' . $ocdi_fields_to_change['_' . $key] . '\',<br>';
		}
	}
	echo ');';
	die();
