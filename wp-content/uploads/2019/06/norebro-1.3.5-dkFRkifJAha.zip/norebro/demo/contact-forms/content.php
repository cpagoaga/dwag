<?php

	// global settings
	$ocdi_fields_to_change = array( );